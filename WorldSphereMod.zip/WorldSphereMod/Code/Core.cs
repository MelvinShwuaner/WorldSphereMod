using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
using CompoundMeshes;
using NeoModLoader.utils;
using NeoModLoader.constants;
using System.IO;
using Newtonsoft.Json;
using static WorldSphereMod.CompoundSphereScripts;
using static HarmonyLib.AccessTools;
using WorldSphereMod.NewCamera;
using UnityEngine.Tilemaps;
using WorldSphereMod.General;
using System.Reflection;
using WorldSphereMod.Effects;
using System;
using WorldSphereMod.TileMapToSphere;
using WorldSphereMod.UI;
using WorldSphereMod.QuantumSprites;
using ai.behaviours;
using Range = CompoundMeshes.Range;
using System.Runtime.CompilerServices;
namespace WorldSphereMod
{
    public static class Core
    {
        public static SavedSettings savedSettings = new SavedSettings();
        public static string SettingsVersion = "1.5";

        public static Harmony Patcher;
        public static void SaveSettings()
        {
            string json = JsonConvert.SerializeObject(savedSettings, Formatting.Indented);
            File.WriteAllText($"{Paths.ModsConfigPath}/WorldSphereMod.json", json);
        }
        public static bool LoadSettings()
        {
            SavedSettings? loadedData;
            try
            {
                loadedData = JsonConvert.DeserializeObject<SavedSettings>(File.ReadAllText($"{Paths.ModsConfigPath}/WorldSphereMod.json"));
                if (loadedData == null || loadedData.Version != SettingsVersion)
                {
                    throw new FileLoadException();
                }
            }
            catch
            {
                SaveSettings();
                return false;
            }
            savedSettings = loadedData;
            return true;
        }

        // go go gadget un-box my worldbox
        public static void Init()
        {
            LoadSettings();
            WorldSphereTab.Begin();
            DimensionConverter.Prepare();
            Patch();
            DoSomeOtherStuff();
        }
        static void DoSomeOtherStuff()
        {
            Constants.PerpBuildings.Add("stockpile_acidproof", true);
            Constants.PerpBuildings.Add("stockpile_fireproof", true);
            Constants.PerpBuildings.Add("stockpile", true);
            Constants.PerpProjectiles.Add("arrow", true);

            AssetManager.hotkey_library.action_hotkeys = AssetManager.hotkey_library.action_hotkeys.AddToArray(AssetManager.hotkey_library.add(new HotkeyAsset()
            {
                id = "Perspective",
                default_key_1 = KeyCode.F5,
                check_window_not_active = true,
                ignore_mod_keys = true,
                allow_unit_control = true,
                check_controls_locked = false,
                just_pressed_action = delegate (HotkeyAsset _)
                {
                    AssetManager.powers.get("first_person").toggle_action("first_person");
                    PowerButtonSelector.instance.checkToggleIcons();
                }
            }));

        }
        // load the textures after mods are loaded incase some mods add new world tiles
        public static void PostInit()
        {
            Sphere.Prepare();
        }
        const string HarmonyID = "WorldSphereMod";
        //this mod makes the game 3D, of course im patching alot (rip compatibility)
        //literally the core function of the mod
        static void Patch()
        {

            Patcher = new Harmony(HarmonyID);
            Patcher.PatchAll();

            Patcher.PatchAll(typeof(SphereControl));
            Patcher.PatchAll(typeof(Dist3D));
            Patcher.PatchAll(typeof(EffectPatches));
            Patcher.PatchAll(typeof(MovementEnhancement));
            Patcher.PatchAll(typeof(Drop3D));
            Patcher.PatchAll(typeof(FixCrabzilla));
            Patcher.PatchAll(typeof(AddLayers));
            Patcher.PatchAll(typeof(QuantumSpritePatches));
            Patcher.PatchAll(typeof(WorldLoop));
            Patcher.PatchAll(typeof(SourcePatches));

            MethodInfo WorldLoopPatch = Method(typeof(WorldLoop), nameof(WorldLoop.Tiles));
            Patcher.Patch(Method(typeof(GeneratorTool), nameof(GeneratorTool.getTile)), new HarmonyMethod(WorldLoopPatch));
            Patcher.Patch(Method(typeof(MapBox), nameof(MapBox.GetTile)), new HarmonyMethod(WorldLoopPatch));

            MethodInfo Lerp3DPatch = Method(typeof(Lerp3D), nameof(Lerp3D.Transpiler));
            Patcher.Patch(Method(typeof(PlayerControl), nameof(PlayerControl.clickedStart)), null, null, new HarmonyMethod(Lerp3DPatch));

            HarmonyMethod brushTranspiler = new HarmonyMethod(Method(typeof(BrushTranspiler), nameof(BrushTranspiler.Transpiler)));
            Patcher.Transpile(Method(typeof(MapAction), nameof(MapAction.applyTileDamage)), brushTranspiler);
            Patcher.Transpile(Method(typeof(MapBox), nameof(MapBox.loopWithBrush), new Type[] { typeof(WorldTile), typeof(BrushData), typeof(PowerActionWithID), typeof(string) }), brushTranspiler);
            Patcher.Transpile(Method(typeof(MapBox), nameof(MapBox.loopWithBrush), new Type[] { typeof(WorldTile), typeof(BrushData), typeof(PowerAction), typeof(GodPower) }), brushTranspiler);
            Patcher.Transpile(Method(typeof(BehWormDigEat), nameof(BehWormDigEat.loopWithBrush)), brushTranspiler);
            Patcher.Transpile(Method(typeof(MapBox), nameof(MapBox.loopWithBrushPowerForDropsRandom)), brushTranspiler);

            MethodInfo EffectPatch = Method(typeof(EffectPatches), nameof(EffectPatches.BasePatch));
            Patcher.Patch(Method(typeof(BaseEffect), nameof(BaseEffect.prepare), new Type[] { }), null, new HarmonyMethod(EffectPatch));
            Patcher.Patch(Method(typeof(BaseEffect), nameof(BaseEffect.prepare), new Type[] {typeof(WorldTile), typeof(float) }), null, new HarmonyMethod(EffectPatch));
            Patcher.Patch(Method(typeof(BaseEffect), nameof(BaseEffect.prepare), new Type[] {typeof(Vector2), typeof(float) }), null, new HarmonyMethod(EffectPatch));
            //may allah forgive me
            HarmonyMethod MapLayerTranspiler = new HarmonyMethod(Method(typeof(AddLayers), nameof(AddLayers.MapLayerTranspiler)));
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawBuildings)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(BurnedTilesLayer), nameof(BurnedTilesLayer.UpdateDirty)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(ConwayLife), nameof(ConwayLife.UpdateVisual)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.clear)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawCitizenJobs)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawConstructionTiles)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawProfession)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawTargetedBy)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawUnitKingdoms)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawUnitsInside)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.drawUnitTiles)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.fill), new Type[] {typeof(List<WorldTile>), typeof(Color), typeof(bool)}), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayer), nameof(DebugLayer.fill), new Type[] { typeof(WorldTile[]), typeof(Color), typeof(bool) }), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayerCursor), nameof(DebugLayerCursor.fill), new Type[] { typeof(List<WorldTile>), typeof(Color), typeof(bool) }), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayerCursor), nameof(DebugLayerCursor.fill), new Type[] { typeof(WorldTile[]), typeof(Color), typeof(bool) }), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(DebugLayerCursor), nameof(DebugLayerCursor.drawIsland)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(ExplosionsEffects), nameof(ExplosionsEffects.UpdateDirty)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(FireLayer), nameof(FireLayer.UpdateDirty)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(LavaLayer), nameof(LavaLayer.drawLavaPixel)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(LavaLayer), nameof(LavaLayer.updateLava)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(PathFindingVisualiser), nameof(PathFindingVisualiser.showPath)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(PixelFlashEffects), nameof(PixelFlashEffects.UpdateDirty)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(UnitLayer), nameof(UnitLayer.UpdateDirty)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(WorldLayerEdges), nameof(WorldLayerEdges.redraw)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(WorldLayerEdges), nameof(WorldLayerEdges.redrawTile)), MapLayerTranspiler);
            Patcher.Transpile(Method(typeof(ZoneCalculator), nameof(ZoneCalculator.applyMetaColorsToZone)), AddLayers.ZoneLayerTranspiler);
            Patcher.Transpile(Method(typeof(ZoneCalculator), nameof(ZoneCalculator.colorZone)), AddLayers.ZoneLayerTranspiler);
            Patcher.Transpile(Method(typeof(ZoneCalculator), nameof(ZoneCalculator.colorZone)), AddLayers.AVerySpecificTranspiler);
            Patcher.Transpile(Method(typeof(ZoneCalculator), nameof(ZoneCalculator.applyMetaColorsToZoneFull)), AddLayers.ZoneLayerTranspiler);
            Patcher.Transpile(Method(typeof(ZoneCalculator), nameof(ZoneCalculator.applyMetaColorsToZoneFull)), AddLayers.AVerySpecificTranspiler);

            Patcher.Transpile(Method(typeof(Actor), nameof(Actor.updateMovement)), Move3D.Transpiler);
            Patcher.Transpile(Method(typeof(Actor), nameof(Actor.tryToAttack)), Move3D.Transpiler);
            Patcher.Transpile(Method(typeof(MapBox), nameof(MapBox.checkAttackFor)), Move3D.Transpiler);
            Patcher.Transpile(Method(typeof(Actor), nameof(Actor.updatePossessedMovementTowards)), Move3D.Transpiler);
            Patcher.Transpile(Method(typeof(CombatActionLibrary), nameof(CombatActionLibrary.getAttackTargetPosition)), Move3D.Transpiler);
            Patcher.Transpile(Method(typeof(MusicBoxContainerTiles), nameof(MusicBoxContainerTiles.calculatePan)), Move3D.Transpiler);

            HarmonyMethod previewPatch = new HarmonyMethod(Method(typeof(PreviewPatch), nameof(PreviewPatch.Prefix)));
            HarmonyMethod previewPatchpostfix = new HarmonyMethod(Method(typeof(PreviewPatch), nameof(PreviewPatch.Postfix)));
            Patcher.Patch(AccessTools.Method(typeof(PreviewHelper), nameof(PreviewHelper.convertMapToTexture)), previewPatch, previewPatchpostfix);
            Patcher.Patch(AccessTools.Method(typeof(PreviewHelper), nameof(PreviewHelper.getCurrentWorldPreview)), previewPatch, previewPatchpostfix);

            Patcher.Transpile(Method(typeof(MoveCamera), nameof(MoveCamera.zoomToBounds)), MinZoomTranspiler.Transpiler);
            Patcher.Transpile(Method(typeof(MoveCamera), nameof(MoveCamera.updateMobileCamera)), MinZoomTranspiler.Transpiler);

            Patcher.Transpile(Method(typeof(HeatRayEffect), nameof(HeatRayEffect.update)), DisableSettingPositions.Transpiler);

            //this is where the fun begins 
            DimensionConverter.ConvertPositions(Method(typeof(Boulder), nameof(Boulder.updateCurrentPosition)), 1);
            DimensionConverter.ConvertPositions(Method(typeof(Boulder), nameof(Boulder.actionLanded)));
            DimensionConverter.ConvertQuantum(Method(typeof(Santa), nameof(Santa.updatePosition)), DimensionConverter.YToZ);
            DimensionConverter.ConvertQuantum(Method(typeof(HeatRayEffect), nameof(HeatRayEffect.play)), DimensionConverter.ToQuantum);

            DimensionConverter.ConvertQuantum(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawShadowsBuildings)), DimensionConverter.ToShadow);
            DimensionConverter.ConvertQuantum(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawFires)), DimensionConverter.ToFire);
            DimensionConverter.ConvertQuantum(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawShadowsUnit)), DimensionConverter.ToShadow);
            DimensionConverter.ConvertPositions(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawUnitAttackRange)));
            DimensionConverter.ConvertPositions(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawUnitSize)));
            DimensionConverter.ConvertPositions(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawUnitsAvatars)));
            DimensionConverter.ConvertPositions(Method(typeof(QuantumSpriteLibrary), nameof(QuantumSpriteLibrary.drawLightAreas)));

            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.setPosOnly), new Type[] {typeof(Vector2)}));
            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.setPosOnly), new Type[] { typeof(Vector2).MakeByRefType() }));
            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.setPosOnly), new Type[] { typeof(Vector3).MakeByRefType() }));
            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.set), new Type[] { typeof(Vector2).MakeByRefType(), typeof(Vector3).MakeByRefType() }));
            DimensionConverter.ConvertQuantum(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.set), new Type[] { typeof(Vector2).MakeByRefType(), typeof(float) }), DimensionConverter.ToQuantum);
            DimensionConverter.ConvertQuantum(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.set), new Type[] { typeof(Vector3).MakeByRefType(), typeof(float) }), DimensionConverter.ToQuantumWithHeight);
            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.set), new Type[] { typeof(Vector3).MakeByRefType(), typeof(Vector2).MakeByRefType() }));
            DimensionConverter.ConvertPositions(Method(typeof(GroupSpriteObject), nameof(GroupSpriteObject.set), new Type[] { typeof(Vector3).MakeByRefType(), typeof(Vector3).MakeByRefType() }));
        } 
        public static void Become3D()
        {
            Sphere.Begin();
            CameraManager.MakeCamera3D();
            Do3DStuff();
        }
        static void Do3DStuff()
        {
            World.world.heat_ray_fx.ray.transform.localPosition = Vector3.zero;
            QuantumSpriteLibrary.light_areas.color = new Color(1, 1, 1, 0.5f);
            World.world.heat_ray_fx.ray.transform.eulerAngles = new Vector3(180, 0, 0);
        }
        public static void Become2D()
        {
            Sphere.Finish();
            CameraManager.MakeCamera2D();
            do2DStuff();
        }
        static void do2DStuff()
        {
            QuantumSpriteLibrary.light_areas.color = new Color(1, 1, 1, 1f);
            World.world.heat_ray_fx.ray.transform.localPosition = new Vector3(0, 2000);
            World.world.heat_ray_fx.ray.transform.eulerAngles = Vector3.zero;
        }
        
        public static PixelFlashEffects FlashLayer => World.world.flash_effects;
        public static bool Generated = false;
        public static bool GeneratingSphere => savedSettings.Is3D && !Generated;
        public static bool IsWorld3D => Sphere.Exists;
        public delegate void PrepareShape(ref int Width, ref int Height);
        /// <summary>
        /// converts a X,Y position and height to a position on the Sphere
        /// </summary>
        public delegate Vector3 To3D(StaticHandler Manager, float x, float y, float height);
        // the layer between the Mod and the compound sphere
        public static class Sphere
        {
            public static Texture2DArray MapLayerArray;
            public static void AddShape(Shape shape)
            {
                Shapes.Add(shape);
            }
            public static Quaternion GetRotation(Vector2 position)
            {
                return CurrentShape.cameraRotation(position);
            }
            public delegate Quaternion GetCameraRot(Vector2 tile);
            public delegate void Initiation(StaticHandler Manager);
            public struct Shape
            {
                public Shape(To2D to2d, To2DFast to2dfast, To3D to3d, string KernelName, Initiation init, GetCameraRange GetCameraRange, GetVector getVector, GetCustomData<Vector3> GetScale, PhaseGate xgate, PhaseGate ygate, PrepareShape isvalid, GetCameraRot getCameraRot)
                {
                    this.To2D = to2d;
                    this.To2DFast = to2dfast;
                    this.To3D = to3d;
                    this.KernelName = KernelName;
                    this.GetScale = GetScale;
                    this.Inititation = init;
                    this.GetCameraRange = GetCameraRange;
                    this.XGate = xgate;
                    YGate = ygate;
                    cameraRotation = getCameraRot;
                    this.GetCameraVector = getVector;
                    this.Prepare = isvalid;
                }
                public PrepareShape Prepare;
                public PhaseGate XGate;
                public PhaseGate YGate;
                public To2D To2D;
                public GetCustomData<Vector3> GetScale;
                public To2DFast To2DFast;
                public To3D To3D;
                public string KernelName;
                public GetCameraRot cameraRotation;
                public Initiation Inititation;
                public GetCameraRange GetCameraRange;
                public GetVector GetCameraVector;
            }
            public static PhaseGate XGate => CurrentShape.XGate;
            public static PhaseGate YGate => CurrentShape.YGate;
            public static float Radius => Width / (2 * Mathf.PI);
            public static int Width => Handler.Rows;
            public static int Height => Handler.Cols;
            public static bool Exists => Manager != null;
            public static float HeightMult = 0;
            public static bool PerlinNoise = true;
            #region Fancy stuff
            static MeshManager Manager;
            static StaticHandler Handler;
            static Mesh CompoundSphereMesh;
            static Material CompoundSphereMaterial;
            static Texture2DArray Textures;
            static ManagerSettings StaticHandlerConfig;
            static Dictionary<Tile, int> TileIDS;
            static ComputeShader WorldSphereShader;
            #endregion
            public static List<MapLayer> BaseLayers;
            public static Dictionary<MapLayer, PixelArray> CachedColors;
            public delegate Vector3 To2D(StaticHandler manager, float x, float y, float z);
            public delegate Vector2 To2DFast(StaticHandler manager, float x, float y, float z);
            static Shape CurrentShape;
            public static void GetCamerRange(out Range X, out Range Y)
            {
                CurrentShape.GetCameraRange(Handler, out X, out Y);
            }
            public static Vector2 GetCameraVector(float Speed, bool Vertical)
            {
                return CurrentShape.GetCameraVector(Speed, Vertical);
            }
            static List<Shape> Shapes = new List<Shape>()
            {
                new Shape(CylindricalToCartesian, CylindricalToCartesianFast, CartesianToCylindrical, "CylindricalWarp", CylindricalInitiation, RenderRange, GetMovementVectorSpherical, StaticTileScaleCylindrical, WrappedGate, DefaultGate, (ref int _, ref int _) => { }, CylindricalRotation), //cylinder
                new Shape(FlatToCartesian, FlatToCartesianFast, CartesianToFlat, "FlatWarp", FlatInitiation, RenderRangeFlat, GetMovementVectorFlat, StaticTileScaleFlat,  DefaultGate, DefaultGate, ( ref int _,  ref int _) => {}, FlatRotation),//flat
               // new Shape(CartesianToCube, CartesianToCubeFast, CubeToCartesian, CubeRotation, CubeInitiation, RenderRangeCube, GetMovementVectorCube, StaticTileScaleCube, DefaultGate, DefaultGate, Tools.Cube.Prepare, CubeRotation)
            };
            public static void SetLayers3D()
            {
                foreach (MapLayer Layer in BaseLayers)
                {
                    CachedColors[Layer].AddLayer = (int I) =>
                    {
                        WorldTile tile = World.world.tiles_list[I];
                        TileMapToSphere.Manager.UpdateColor(tile);
                    };
                }
                CachedColors[FlashLayer].AddLayer = (int I) =>
                {
                    WorldTile tile = World.world.tiles_list[I];
                    UpdateLayer(tile.Index());
                };
            }
            public static void SetLayers2D()
            {
                foreach(var Layer in CachedColors)
                {
                    Layer.Value.AddLayer = null;
                }
            }
            public static void Begin()
            {
                SetLayers3D();
                HeightMult = savedSettings.TileHeight;
                PerlinNoise = Core.savedSettings.PerlinNoise;
      
                int width = MapBox.width;
                int height = MapBox.height;
                CreateSettings(width, height);
                Scales = new float[width * height];

                MapLayerArray = new Texture2DArray(width, height, CachedColors.Count, TextureFormat.RGBA32, false, false)
                {
                    filterMode = FilterMode.Point,
                    wrapMode = TextureWrapMode.Clamp
                };
                for (int i = 0; i < CachedColors.Count; i++)
                {
                    MapLayerArray.SetPixels32(World.world._map_layers[i].pixels, i);
                }

                Manager = MeshManager.CreateMeshManager(StaticHandlerConfig, "StaticHandler");
                CurrentShape.Inititation(Handler);

                Manager.SetComputeProperty("BlendLayers", "Layers", MapLayerArray);
                Manager.SetComputeProperty("FlashEffects", "Layers", MapLayerArray);
                MapLayerArray.Apply();

                Manager.SetComputeProperty("LayerCount", 12);
                Manager.SetComputeProperty("TextureWidth", height);
                Manager.SetComputeProperty("ZDisplacement", Constants.ZDisplacement);
                Manager.SetComputeProperty("Radius", width / (2 * Mathf.PI));

                Manager.SetProperty("WaveFrequency", 0.5f); // controls how tightly packed the waves are
                Manager.SetProperty("WaveSpeed", 1f);     // controls how fast they move
                Manager.SetProperty("WaveAmplitude", 1f);
                Manager.SetProperty("WavesEnabled", 0);

                Manager.SetProperty("TextureArray", Textures);

                for (int i = 0; i < width*height; i++)
                {
                    Manager.UpdateAll(i);
                }
                Manager.RefreshAll();
            }
            public static Color32 GetAddedColor(int Index)
            {
                return FlashLayer.pixels[Index].Normalised();
            }
            public static void UpdateScale(StaticTile Tile)
            {
                Manager.Update("Scales", Tile.Index);
            }
            public static void UpdateTexture(StaticTile Tile)
            {
                Manager.Update("Textures", Tile.Index);
            }
            public static bool MapLayersDirty = false;
            public static void RefreshSphere()
            {
                Manager.SetProperty("Time", Time.time);
                MapLayerArray.Apply();
                Manager.RefreshAll();
            }
            public static void UpdateLayer(int Index)
            {
                Manager.Update("AddedColors", Index);
            }
            public static void UpdateBaseLayer(int Index)
            {
                Manager.Update("Colors", Index);
            }
            public static void PrepareShape(ref int Width, ref int Height)
            {
                CurrentShape = Shapes[savedSettings.CurrentShape];
                CurrentShape.Prepare(ref Width, ref Height);
            }
            public static void Finish()
            {
                if (Manager == null || Manager.gameObject == null)
                {
                    return;
                }
                SetLayers2D();
                Manager.Destroy();
            }
            public static void CheckWave(StaticTile Tile)
            {
                Manager.Update("Waves", Tile.Index);
            }
            public static Vector3 TilePosWithHeight(float X, float Y, float Z)
            {
                return CurrentShape.To2D(Handler, X, Y, Z);
            }
            public static Vector2 TilePos(float X, float Y, float Z)
            {
                return CurrentShape.To2DFast(Handler, X, Y, Z);
            }
            public static void DrawTiles(int CameraX, int CameraY)
            {
                Handler.RefreshRanges(CameraX, CameraY);
                Manager.SetProperty("ShouldRenderTextures", getdisplaymode());
                Manager.DrawMeshes();
            }
            static void CreateCachedColors()
            {
                int Index = 0;
                CachedColors = new Dictionary<MapLayer, PixelArray>();
                foreach (var layer in World.world._map_layers)
                {
                    CachedColors.Add(layer, new PixelArray(layer, Index++));
                }
            }
            public static Vector3 SpherePos(float X, float Y, float Height = 0)
            {
                return CurrentShape.To3D(Handler, X, Y, Height);
            }
            public static void Prepare()
            {
                LoadAssets();
                CreateTextures();
                BaseLayers = new List<MapLayer>(World.world._map_layers);
                BaseLayers.Remove(FlashLayer);
                CreateCachedColors();
            }
            public static int WorldTileTexture(WorldTile Tile)
            {
                Tile Graphic = Tools.getVariation(Tile);
                if(Graphic == null)
                {
                    return 0;
                }
                if (TileIDS.TryGetValue(Graphic, out int ID)) {
                    return ID;
                }
                return 0;
            }
            static void LoadAssets()
            {
                WrappedAssetBundle ab = AssetBundleUtils.GetAssetBundle("worldsphere");
                CompoundSphereMesh = ab.GetObject<Mesh>("assets/worldspheremod/compoundspheremesh.asset");
                CompoundSphereMaterial = ab.GetObject<Material>("assets/worldspheremod/compoundspherematerial.mat");
                WorldSphereShader = ab.GetObject<ComputeShader>("assets/worldspheremod/compoundcomputeshader.compute");
                CameraManager.Begin(ab.GetObject<Material>("assets/worldspheremod/SkyBox.mat").shader);
                LibraryMaterials.instance._night_affected_colors.Add(CompoundSphereMaterial);
            }
            public static StaticTile GetTile(int X, int Y)
            {
                return Handler[X, Y];
            }
            public static StaticTile GetTile(int I)
            {
                return Handler.GetTile(I);
            }
            static void CreateSettings(int Width, int Height)
            {
                Handler = new StaticHandler(Width, Height, CurrentShape.GetCameraRange);
                StaticHandlerConfig = new ManagerSettings(
                    CompoundSphereMesh,
                    CompoundSphereMaterial,
                    WorldSphereShader,
                    new List<IBufferData>() { 
                        new ComputeGraphicsBufferData<Color32>("AddedColors", "OutputColors", "FlashEffects"),
                        new ComputeBufferData<Vector2>("InputPositions", CurrentShape.KernelName, GetPosition),
                        new ComputeGraphicsBufferData<Matrix4x4>("Matrixes", "OutputMatrices", CurrentShape.KernelName),
                        new ComputeGraphicsBufferData<Color32>("Colors", "OutputColors", "BlendLayers"),
                        new GraphicsBufferData<Vector3>("Scales", CurrentShape.GetScale),
                        new GraphicsBufferData<float>("Textures", StaticTileTexture),
                        new GraphicsBufferData<float>("Waves", IsWave) 
                    },
                    Handler
               );
            }
            static void CreateTextures()
            {
                List<Sprite> Sprites = new List<Sprite>();
                TileIDS = new Dictionary<Tile, int>();
                foreach (TileType type in AssetManager.tiles.list)
                {
                    AddTile(type);
                }
                foreach (TopTileType type in AssetManager.top_tiles.list)
                {
                    AddTile(type);
                }
                Textures = new Texture2DArray(8, 8, Sprites.Count, TextureFormat.RGBA32, true, false)
                {
                    filterMode = FilterMode.Point,
                    wrapMode = TextureWrapMode.Clamp
                };
                for (int i = 0; i < Sprites.Count; i++)
                {
                    Textures.SetPixels32(GetTruePixels(Sprites[i]), i);
                }
                Textures.Apply();
                void AddTile(TileTypeBase Tile)
                {
                    TileSprites sprites = Tile.sprites;
                    if (sprites == null)
                    {
                        return;
                    }
                    foreach (Tile tile in sprites._tiles)
                    {
                        if (TileIDS.TryAdd(tile, Sprites.Count))
                        {
                            Sprites.Add(tile.sprite);
                        }
                    }
                }
                Color32[] GetTruePixels(Sprite sprite)
                {
                    if (sprite.texture.width > 8 || sprite.texture.height > 8)
                    {
                        //seperate a sprite from its atlas
                        //this shit took me hours to solve
                        return sprite.PixelsFromSpriteAtlas();
                    }
                    return Tools.ExpandArray(sprite.texture.GetPixels32(), 64);
                }
            }
        }
    }
}