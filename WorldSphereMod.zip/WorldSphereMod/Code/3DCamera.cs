﻿using HarmonyLib;
using SleekRender;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Reflection.Metadata.Ecma335;
using UnityEngine;
using UnityEngine.UI;
using WorldBoxConsole;
using WorldSphereMod.General;
using static WorldSphereMod.NewCamera.CameraManager;
namespace WorldSphereMod.NewCamera
{
    //yes this feels like cheating
    [HarmonyPatch(typeof(Camera), "get_orthographicSize")]
    public class GetSize
    {
        public static bool Prefix(ref float __result)
        {
            if (Core.IsWorld3D)
            {
                __result = Height;
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.isWithinCameraViewNotPowerBar))]
    class Bounds
    {
        public static bool Prefix(ref bool __result, Vector2 pPos)
        {
            if (Core.IsWorld3D)
            {
                __result = IsWithinCameraView(pPos.To3DTileHeight(10));
                return false;
            }
            return true;
        }
        public static bool IsWithinCameraView(Vector3 Pos)
        {
            Vector3 ScreenPos = MainCamera.WorldToViewportPoint(Pos);
            if(ScreenPos.x > 1 || ScreenPos.x < 0 || ScreenPos.y > 1 || ScreenPos.y < 0 || ScreenPos.z < 0)
            {
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(WorldAgeEffects), nameof(WorldAgeEffects.fitTheCamera))]
    public class AgeEffects
    {
        public static bool Prefix(WorldAgeEffects __instance)
        {
            if (Core.IsWorld3D)
            {
                FitCamera(__instance.transform);
                return false;
            }
            return true;
        }
        public static void FitCamera(Transform Transform)
        {
            Transform.position = transform.TransformPoint(new Vector3(0, 0, 1));
            Transform.rotation = transform.rotation;
            Transform.localScale = new Vector3(2.2f, 2, 1);
        }
    }
    [HarmonyPatch(typeof(Camera), "set_orthographicSize")]
    public class SetSize
    {
        public static bool Prefix(float value)
        {
            if (Core.IsWorld3D)
            {
                Height = value;
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), "update")]
    //this manages the camera
    public static class CameraManager
    {
        public static Vector2 Position => Manager.transform.position;
        public static Transform transform => MainCamera.transform;
        public static void MakeCamera3D()
        {
            OriginalCamera.enabled = false;
            MainCamera.enabled = true;
            Manager.main_camera = MainCamera;
        }
        public static void MakeCamera2D()
        {
            OriginalCamera.enabled = true;
            MainCamera.enabled = false;
            Manager.main_camera = OriginalCamera;
        }
        public static Texture GetSkyboxTexture()
        {
            Sprite sprite = Resources.Load<Sprite>("WorldSphereMod/SkyBox");
            return sprite.texture;
        }
        //i want to rename this function to prepare but for some reason that breaks something. this is so fucking random i have no fucking idea how thats even possible
        public static void Begin(Shader SkyBoxShader)
        {
            MainCamera = new GameObject("WorldSphere Camera").AddComponent<Camera>();
            MainCamera.gameObject.tag = "MainCamera";
            MainCamera.transparencySortMode = TransparencySortMode.Default;
            
            Manager = MoveCamera.instance;
            OriginalCamera = Manager.main_camera;
            Tools.CopyComponent(OriginalCamera.GetComponent<SleekRenderPostProcess>(), MainCamera.gameObject);
            MainCamera.clearFlags = CameraClearFlags.Skybox;
            MainCamera.AddComponent<Skybox>();
            MainCamera.GetComponent<Skybox>().material = new Material(SkyBoxShader)
            {
                mainTexture = GetSkyboxTexture()
            };
            RotateCamera.UpdateRotation(Vector2.zero);
        }
        public static MoveCamera Manager;
        public static Camera MainCamera;
        public static Camera OriginalCamera;
        public static float Height;
        public static float MaxHeight => Manager.orthographic_size_max;
        static void Postfix()
        {
            if (!Core.IsWorld3D)
            {
                return;
            }
            MainCamera.transform.position = Core.Sphere.SpherePos(Position.x, Position.y, Height);
            MainCamera.transform.rotation = (Core.savedSettings.CameraRotatesWithWorld ? Core.Sphere.GetRotation(MainCamera.transform.position) * Constants.ToUpright : Quaternion.identity) * Quaternion.Euler(RotateCamera.Rotation);
            if (ControllableUnit._unit_main != null && Core.savedSettings.FirstPerson)
            {
                Manager._target_zoom = ControllableUnit._unit_main.position_height + ControllableUnit._unit_main.GetHeight() + CameraTile.TileHeight();
            }
            float MinZoom = CameraTile.TileHeight() + 1;
            if (Manager._target_zoom < MinZoom)
            {
                Manager._target_zoom = MinZoom;
            }
            Bench.bench("Draw Sphere", "game_total"); //im not even sure if the lag is actually tracked
            Core.Sphere.DrawTiles((int)Position.x, (int)Position.y);
            Bench.benchEnd("Draw Sphere", "game_total");
        }
        
        public static WorldTile CameraTile
        {
            get
            {
                Vector2Int pos = Position.AsIntClamped();
                return World.world.GetTile(pos.x, pos.y);
            }
        }
    }
    public delegate Vector2 GetVector(float Speed, bool Vertical);
    public class MovementEnhancement
    {
        static bool UpsideDown => Vector3.Dot(transform.up, Vector3.up) < 0;
        public static Vector2 GetMovementVector(float Speed, bool Vertical)
        {
            return Core.Sphere.GetCameraVector(Speed, Vertical);
        }
        public static void Move(HotkeyAsset pAsset)
        {
            string id = pAsset.id;
            float tMove = MoveCamera.getMoveDistance(pAsset.id.StartsWith("fast_"));
            float Change = id.Contains("up") || id.Contains("right") ? tMove : -tMove;
            bool Vertical = id.Contains("down") || id.Contains("up");
            Manager._move_velocity += GetMovementVector(Change, Vertical);
        }
        [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.move))]
        [HarmonyPrefix]
        public static bool movecamera(HotkeyAsset pAsset)
        {
            if (Core.IsWorld3D)
            {
                Move(pAsset);
                return false;
            }
            return true;
        }
        [HarmonyPatch(typeof(ControllableUnit), nameof(ControllableUnit.updateMovementVectorKeyboard))]
        [HarmonyPostfix]
        public static void movepossesed()
        {
            if (ControllableUnit._movement_vector != Vector2.zero)
            {
                UpdatePossesed();
            }
        }
        public static void UpdatePossesed()
        {
            if (!Core.IsWorld3D)
            {
                return;
            }
            Vector2 Vector = ControllableUnit._movement_vector;
            ControllableUnit._movement_vector = Vector2.zero;
            ControllableUnit._movement_vector += GetMovementVector(Vector.y, true);
            ControllableUnit._movement_vector += GetMovementVector(Vector.x, false);
        }
        [HarmonyPatch(typeof(ControllableUnit), nameof(ControllableUnit.updateMovementVectorJoystick))]
        [HarmonyPostfix]
        public static void movepossesedjoystick()
        {
            if (ControllableUnit.isMovementActionActive())
            {
                UpdatePossesed();
            }
        }
        [HarmonyPatch(typeof(ControllableUnit), nameof(ControllableUnit.updateCamera))]
        [HarmonyPrefix]
        public static bool updateCamera()
        {
            Vector2 tPos = ControllableUnit._unit_main.current_position;
            Vector3 tCam = World.world.camera.transform.position;
            tCam.x = tPos.x;
            tCam.y = tPos.y;
            if (!Core.savedSettings.FirstPerson && Core.IsWorld3D)
            {
                tCam += (Vector3)GetMovementVector(-Height/2, true);
            }
            float tSpeed = 1f / World.world.camera.orthographicSize;
            World.world.camera.transform.position = Vector3.Lerp(World.world.camera.transform.position, tCam, tSpeed);
            return false;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.updateMouseCameraDrag))]
    public class RotateCamera
    {
        public static Vector3 Rotation = new Vector3(30, 90);
        static bool Prefix()
        {
            if (Core.IsWorld3D)
            {
                UpdatePanning(Manager);
                return false;
            }
            return true;
        }
        public static float InvertMult
        {
            get { return Rotation.x < 90 || Rotation.x > 270 || !Core.savedSettings.UpsideDownMovement ? 1 : -1; }
        }
        public static void UpdateRotation(Vector2 Change)
        {
            Rotation.x = Tools.MathStuff.WrappedChange(Rotation.x, -Change.y, 360);
            Rotation.y = Rotation.y + (Change.x * InvertMult);
        }
        //i dont know how this fucking works and im too scared to touch it
        static void UpdatePanning(MoveCamera Cam)
        {
            MoveCamera.camera_drag_run = false;
            bool tInputDetectedDown = false;
            bool tInputDetected = false;
            if (InputHelpers.mouseSupported)
            {
                tInputDetectedDown = Cam.checkMouseInputDown();
                tInputDetected = Cam.checkMouseInput();
            }
            if (!tInputDetected)
            {
                Cam.clearTouches();
                return;
            }
            if (tInputDetectedDown && World.world.isOverUI())
            {
                Cam.clearTouches();
                return;
            }
            Vector3 Position = Input.mousePosition;
            if (tInputDetectedDown && Cam._origin.x == -1f && Cam._origin.z == -1f)
            {
                Cam._origin = Position;
            }
            if (Cam._origin.x == -1f && Cam._origin.y == -1f && Cam._origin.z == -1f)
            {
                return;
            }
            if (tInputDetected)
            {
                MoveCamera.camera_drag_run = true;
                Vector3 MousePos = Position;
                if (Toolbox.DistVec3(Vector3.zero, Position) > 0.1f)
                {
                    MoveCamera.camera_drag_activated = true;
                }
                Vector3 Change = MousePos - Cam._origin;
                Cam._origin = MousePos;
                if (InputHelpers.touchSupported)
                {
                    MoveCamera._touch_dist = Toolbox.DistVec3(Cam._first_touch, Cam.getTouchPos(true));
                    if (World.world.player_control.touch_ticks_skip > 5)
                    {
                        if (MoveCamera._touch_dist >= 20f || (float)World.world.player_control.touch_ticks_skip > 0.3f)
                        {
                            World.world.player_control.already_used_zoom = true;
                            World.world.player_control.already_used_power = false;
                        }
                    }
                    else if (InputHelpers.touchCount == 1)
                    {
                        return;
                    }
                }
                if (!InputHelpers.mouseSupported)
                {
                    return;
                }
                UpdateRotation(Change / 2);
            }
        }
    }
    [HarmonyPatch(typeof(PixelDetector), nameof(PixelDetector.IntersectsSprite))]
    public class GetStaticTileUnderMouse
    {
        //who knew that finding the position your mouse touches on a 3d tube is simpler the finding it on a 2d square
        static bool Prefix(Ray ray, ref Vector2Int pVector, ref bool __result)
        {
            if (Core.IsWorld3D)
            {
                __result = Tools.IntersectMesh(ray, out Vector2 Vector);
                pVector = Vector.AsInt();
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.cameraToBounds))]
    public class Bounds3D
    {
        static void ToBounds3D()
        {
            Vector3 pos = default;
            pos.x = Mathf.Clamp(Core.Sphere.XGate.GetChange(Manager.transform.position.x, 0, Core.Sphere.Width), 0, Core.Sphere.Width);
            pos.y = Mathf.Clamp(Core.Sphere.YGate.GetChange(Manager.transform.position.y, 0, Core.Sphere.Height), 0, MapBox.height-0.5f);
            pos.z = -0.5f;
            Manager.transform.position = pos;
            World.world.nameplate_manager.update();
        }
        static bool Prefix()
        {
            if (Core.IsWorld3D)
            {
                ToBounds3D();
                return false;
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.resetZoom))]
    public class Size3D
    {
        static float AsMaxHeight(float Num)
        {
            return Num/2;
        }
        static void ResetZoom()
        {
            int tInitialZoom;
            if (Screen.width < Screen.height)
            {
                tInitialZoom = Screen.width / 4;
            }
            else
            {
                tInitialZoom = Screen.height / 4;
            }
            int width = MapBox.width / 2;
            int height = MapBox.height;
            if (width > height)
            {
                Manager.orthographic_size_max = AsMaxHeight(width);
            }
            else
            {
                Manager.orthographic_size_max = AsMaxHeight(height);
            }
            if (tInitialZoom > Manager.orthographic_size_max)
            {
                tInitialZoom = (int)Manager.orthographic_size_max;
            }
            Manager._target_zoom = tInitialZoom;
            Manager.main_camera.orthographicSize = Mathf.Clamp(Manager._target_zoom, 2f, Manager.orthographic_size_max);
            World.world.setZoomOrthographic(Manager.main_camera.orthographicSize);
            Manager.main_camera.farClipPlane = 20000;
        }
        static bool Prefix()
        {
            if (Core.savedSettings.Is3D)
            {
                ResetZoom();
                return false;
            }
            return true;
        }
    }
    static class MinZoomTranspiler
    {
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            CodeMatcher Matcher = new CodeMatcher(instructions);
            while (Matcher.FindNext(new CodeInstruction(OpCodes.Ldc_R4, 10f)))
            {
                Matcher.RemoveInstruction();
                Matcher.Insert(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(MinZoomTranspiler), nameof(GetMinZoom))));
            }
            return Matcher.Instructions();
        }
        public static float GetMinZoom()
        {
            if (Core.IsWorld3D)
            {
                return CameraTile.TileHeight() + 1;
            }
            return 10;
        }
    }
    [HarmonyPatch(typeof(MoveCamera), nameof(MoveCamera.updateVelocity))]
    class UpdateVelocity
    {
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            CodeMatcher Matcher = new CodeMatcher(instructions);
            Matcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(InputHelpers), nameof(InputHelpers.GetMouseButton))));
            {
                Matcher.RemoveInstruction();
                Matcher.Insert(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(UpdateVelocity), nameof(GetMouseIf2D))));
            }
            return Matcher.Instructions();
        }
        public static bool GetMouseIf2D(int pButton)
        {
            if (Core.IsWorld3D)
            {
                return false;
            }
            return InputHelpers.GetMouseButton(pButton);
        }
    }
}