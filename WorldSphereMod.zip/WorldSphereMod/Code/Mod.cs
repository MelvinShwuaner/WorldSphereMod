﻿using CompoundSpheres;
using NeoModLoader.api;
using NeoModLoader.constants;
using System;
using System.IO;
using UnityEngine;
using WorldSphereMod;
    public class Mod : MonoBehaviour, IMod, IStagedLoad, ILocalizable
{
    public ModDeclare GetDeclaration()
    {
        return declare;
    }
    public GameObject GetGameObject()
    {
        return Object;
    }
    public void OnLoad(ModDeclare pModDecl, GameObject pGameObject)
    {
        declare = pModDecl;
        Object = pGameObject;
        if (!SystemInfo.supportsInstancing || !SystemInfo.supportsComputeShaders || !SystemInfo.supportsIndirectArgumentsBuffer)
        {
            throw new PlatformNotSupportedException();
        }
    }
    public string GetUrl()
    {
        return "https://github.com/MelvinShwuaner?tab=repositories";
    }

    public void Init()
    {
        Core.Init();
    }

    public void PostInit()
    {
        Core.PostInit();
    }

    public string GetLocaleFilesDirectory(ModDeclare pModDeclare)
    {
        return Path.Combine(pModDeclare.FolderPath, "Locales");
    }
    public static string ModDirectory
    {
        get
        {
            return declare.FolderPath;
        }
    }

    public static GameObject Object;
    static ModDeclare declare;
}
